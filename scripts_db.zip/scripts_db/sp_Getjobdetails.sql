USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[GETJOBDETAILS]    Script Date: 26-05-2022 21:21:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GETJOBDETAILS] 
	
AS
BEGIN
	
	SET NOCOUNT ON;

   
	SELECT * from job_search_master
END
GO

