USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[CreateJob]    Script Date: 26-05-2022 21:20:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CreateJob] 
	-- Add the parameters for the stored procedure here
	@Title varchar(50),
	@Description varchar(10),
	@LocationId int,
	@DepartmentId int,
    @ClosingDate dateTime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	insert into JOB_SEARCH_MASTER
	values(@Title,@Description,@LocationId,@DepartmentId,getdate(),@ClosingDate);

    
END
GO

