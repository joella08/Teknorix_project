USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[UpdateDepartmentsById]    Script Date: 26-05-2022 21:23:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateDepartmentsById]
	@DepartmentID int,
	@title varchar(100)
	
AS
BEGIN
	update departmentMaster set department_title=@title  where Department_id=@DepartmentID
END
GO

