USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[UpdateJob]    Script Date: 26-05-2022 21:24:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateJob] 
	-- Add the parameters for the stored procedure here
	@job_info_id int,
	@Title varchar(50),
	@Description varchar(10),
	@Location_Id int,
	@Department_Id int,
    @ClosingDate dateTime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update JOB_SEARCH_MASTER set Title=@Title,Description=@Description,Location_Id=@Location_Id,
	@Department_Id=Department_Id,ClosingDate=@ClosingDate where job_info_id=@job_info_id
END
GO

