USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[GetDepartmentsById]    Script Date: 26-05-2022 21:21:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetDepartmentsById]
	@DepartmentID int
	
AS
BEGIN
	select * from departmentMaster where Department_id=@DepartmentID
END
GO

