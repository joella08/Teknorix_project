USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[UpdateLocationById]    Script Date: 26-05-2022 21:24:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateLocationById]
	@LocationID int,
	@title varchar(100),@city varchar(100),@state varchar(100),@country varchar(100),@zip int
	
AS
BEGIN
	update Location_master set title=@title , city=@city ,state=@state, country=@country,
	zip=@zip where location_id=@LocationID
END
GO

