USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[getLocationById]    Script Date: 26-05-2022 21:22:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getLocationById]
	@LocationID int
	
	
AS
BEGIN
	select * from Location_master where location_id=@LocationID
END
GO

