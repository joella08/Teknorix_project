USE [JOB_SEARCH]
GO

/****** Object:  Table [dbo].[Job_Search_Master]    Script Date: 26-05-2022 21:19:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Job_Search_Master](
	[Job_Info_id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [nchar](10) NULL,
	[Location_Id] [int] NULL,
	[Department_Id] [int] NULL,
	[PostedDate] [datetime] NULL,
	[ClosingDate] [datetime] NULL,
 CONSTRAINT [PK_Job_Search_Master] PRIMARY KEY CLUSTERED 
(
	[Job_Info_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Job_Search_Master]  WITH CHECK ADD FOREIGN KEY([Department_Id])
REFERENCES [dbo].[Department_Master] ([Department_Id])
GO

ALTER TABLE [dbo].[Job_Search_Master]  WITH CHECK ADD FOREIGN KEY([Location_Id])
REFERENCES [dbo].[Location_Master] ([Location_Id])
GO

