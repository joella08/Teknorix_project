USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[JobGetById]    Script Date: 26-05-2022 21:22:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[JobGetById] 
	-- Add the parameters for the stored procedure here
	@job_info_id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
		
	

	SELECT jsm.title, 
	jsm.[description],
	jsm.location_id,
	lm.Title,
	lm.city,lm.[state],
	dm.department_id,
	dm.department_title,
	lm.country,lm.zip
FROM job_search_master jsm
LEFT JOIN location_master lm
ON jsm.location_id  = lm.location_id

LEFT JOIN  department_master dm on jsm.department_id=dm.department_id
END
GO

