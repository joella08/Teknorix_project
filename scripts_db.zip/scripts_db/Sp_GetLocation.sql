USE [JOB_SEARCH]
GO

/****** Object:  StoredProcedure [dbo].[getLocation]    Script Date: 26-05-2022 21:21:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getLocation]
	
	
	
AS
BEGIN
	select * from Location_master 
END
GO

