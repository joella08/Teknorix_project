﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Http;
using System.Data;

namespace Teknorix_project.Controllers
{
    public class JobDetailsController : ApiController
    {
       public 
        
            public IEnumerable<Job_Search_Master>
          
    }
}