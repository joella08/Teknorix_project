﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Teknorix_project.Models
{
    public class LocationModel
    {
        public int Location_Id { get; set; }
        public int Title { get; set; }
        public int City { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int Zip { get; set; }
    }                              
} 