﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Teknorix_project.Models
{
    public class JobDetailsModel
    {
        public int Job_Info_id {get;set;}
        public string Title {get;set;}
        public string Description {get;set;}
        public int Location_Id {get;set;}
        public int Department_Id{get;set;}
        public DateTime PostedDate  {get;set;}
        public DateTime ClosingDate { get; set; }
    }
}