﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Teknorix_project.Models
{
    public class DepartmentModel
    {
        public int Department_Id { get; set; }
        public string Department_Title { get; set; }
    }
}