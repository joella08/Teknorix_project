﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Teknorix_project.Models;
using Microsoft.EntityFrameworkCore;


using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Teknorix_project.Repository
{
    public class JobDetails : IJobDetails
    {
         async Task<JobDetailsModel> IJobDetails.Get()
        {


            SqlConnection sqlconn = new SqlConnection("Data Source=#;Initial Catalog=#;User ID=#;Password=#");

            SqlCommand sql = new SqlCommand("dbo.[CreateJob]");
            sqlconn.Open();
            sql.Connection = sqlconn;
            sql.CommandType = CommandType.StoredProcedure;
            

            SqlDataReader sdr = sql.ExecuteReader();
            List<JobDetailsModel> lstJobDtls = new List<JobDetailsModel>();
            JobDetailsModel JobDtls = new JobDetailsModel();
            while(sdr.Read())
            {


                JobDtls.Title = sdr["TITLE"].ToString();
                JobDtls.Job_Info_id = int.Parse(sdr["Job_Info_id"].ToString());
                JobDtls.PostedDate = Convert.ToDateTime(sdr["POSTEDDATE"].ToString()); 
                JobDtls.ClosingDate = Convert.ToDateTime(sdr["CLOSINGDATE"].ToString());

                lstJobDtls.Add(JobDtls);
            }

            return JobDtls;

            
        }

        
         async Task<OutputResult> IJobDetails.Create(JobDetailsModel JobDetails)
        {

           
            SqlConnection sqlconn = new SqlConnection("Data Source=#;Initial Catalog=#;User ID=#;Password=#");
            
            SqlCommand sql = new SqlCommand("dbo.[CreateJob]");
            sqlconn.Open();
            sql.Connection = sqlconn;
            sql.CommandType = CommandType.StoredProcedure;
            sql.Parameters.AddWithValue("@Title", JobDetails.Title);
            sql.Parameters.AddWithValue("@Description", JobDetails.Description);
            sql.Parameters.AddWithValue("@LocationId", JobDetails.Location_Id);
            sql.Parameters.AddWithValue("@DepartmentId", JobDetails.Department_Id);
            sql.Parameters.AddWithValue("@ClosingDate", JobDetails.ClosingDate);
          
            SqlDataReader sdr = sql.ExecuteReader();

            if (sdr.Read())
            {
                return new OutputResult()
                {
                    Result = true,
                    ResultMessage = "Success",
                    Status = HttpStatusCode.OK
                };
            }
            else
            {
                return new OutputResult()
                {
                    Result = false,
                    ResultMessage = "Error",
                    Status = HttpStatusCode.Forbidden
                };
            }
           
            //throw new NotImplementedException();
        }

        
         async Task<OutputResult> IJobDetails.Update(JobDetailsModel JobDetails)
        {
            SqlConnection sqlconn = new SqlConnection("Data Source=#;Initial Catalog=#;User ID=#;Password=#");
            SqlCommand sqlcomm = new SqlCommand("dbo.USP_INS_UPD_JOBS");
            sqlconn.Open();
            sqlcomm.Connection = sqlconn;
            sqlcomm.CommandType = CommandType.StoredProcedure;
            sqlcomm.Parameters.AddWithValue("@Id", JobDetails.Job_Info_id);
            sqlcomm.Parameters.AddWithValue("@Title", JobDetails.Title);
            sqlcomm.Parameters.AddWithValue("@Description", JobDetails.Description);
            sqlcomm.Parameters.AddWithValue("@LocationId", JobDetails.Location_Id);
            sqlcomm.Parameters.AddWithValue("@DepartmentId", JobDetails.Department_Id);
            sqlcomm.Parameters.AddWithValue("@ClosingDate", JobDetails.ClosingDate);

            //sqlcomm.ExecuteNonQuery();
            SqlDataReader sdr = sqlcomm.ExecuteReader();
            if (sdr.Read())
            {
                return new OutputResult()
                {
                    Result = true,
                    ResultMessage = "Success",
                    Status = HttpStatusCode.OK
                };
            }
            else
            {
                return new OutputResult()
                {
                    Result = false,
                    ResultMessage = "Error",
                    Status = HttpStatusCode.Forbidden
                };
            }
            

        }

        async Task<JobDetailsModel> IJobDetails.JobDetails_getbyId(int id)
        {
            SqlConnection sqlconn = new SqlConnection("Data Source=#;Initial Catalog=#;User ID=#;Password=#");
            SqlCommand sqlcomm = new SqlCommand("dbo.USP_GET_JOB_DTLS");
            sqlconn.Open();
            sqlcomm.Connection = sqlconn;
            sqlcomm.CommandType = CommandType.StoredProcedure;
            sqlcomm.Parameters.AddWithValue("@JobId", id);
            //sqlcomm.Parameters.AddWithValue("@LocationId", id);

            //sqlcomm.ExecuteNonQuery();
            SqlDataReader sdr = sqlcomm.ExecuteReader();

            List<JobDetailsModel> lstJobDtls = new List<JobDetailsModel>();
            JobDetailsModel JobDtls = new JobDetailsModel();

            while (sdr.Read())
            {

                
                JobDtls.Title = sdr["TITLE"].ToString();
                JobDtls.Job_Info_id = int.Parse(sdr["Job_Info_id"].ToString());
                JobDtls.PostedDate = Convert.ToDateTime(sdr["POSTEDDATE"].ToString());
                JobDtls.ClosingDate = Convert.ToDateTime(sdr["CLOSINGDATE"].ToString());

                lstJobDtls.Add(JobDtls);
            }

            return JobDtls;
        }

        
        

        
       

       

        
       
    }
}
