﻿
using Teknorix_project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Teknorix_project.Repository
{
    public interface IJobDetails
    {

        Task<JobDetailsModel> Get();
        Task<JobDetailsModel> JobDetails_getbyId(int id);
        Task<OutputResult> Create(JobDetailsModel JobDetails);
        Task<OutputResult> Update(JobDetailsModel JobDetails);
        
    }
}